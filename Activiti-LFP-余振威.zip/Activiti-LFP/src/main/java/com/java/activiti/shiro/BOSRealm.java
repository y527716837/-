package com.java.activiti.shiro;

import java.awt.List;
import java.util.ArrayList;

import javax.mail.Session;
import javax.sound.midi.MidiDevice.Info;

import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.activiti.dao.MemberShipDao;
import com.java.activiti.dao.UserDao;
import com.java.activiti.model.MemberShip;
import com.java.activiti.model.User;

public class BOSRealm extends AuthorizingRealm {
    @Autowired
	UserDao userdao;
    @Autowired
    MemberShipDao membershipdao;
	//这个是登陆认证方法
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
		// TODO Auto-generated method stub
		System.out.println("进入至登陆验证的权限区域");
		UsernamePasswordToken upToken = (UsernamePasswordToken) token;//token令牌强转
		String username = upToken.getUsername();
		//查询用户
		User user = userdao.findById(username); 
		if(user==null) {
			//用户不存在
			return null;
		}else {
			//用户存在
			String  password= user.getPassword();
			SimpleAuthenticationInfo info=new SimpleAuthenticationInfo(user,password,this.getClass().getSimpleName());
			return info;
		}
		
	}
    //这个是权限分配方法
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
		// TODO Auto-generated method stub
		System.out.println("进入至权限分配的地址");
		//1.跟据principals获取已经完成认证的用户
		User user= (User)principals.getPrimaryPrincipal();
		System.out.println(user.getId());
		MemberShip memberShip =  membershipdao.getusership(user.getId());
		SimpleAuthorizationInfo info= new SimpleAuthorizationInfo();
		info.addRole(memberShip.getGroup().getName());
		System.out.println(memberShip.getGroup().getName());
		return info;
	}

}